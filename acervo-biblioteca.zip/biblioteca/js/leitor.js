// ============================================
// Leitor — carregamento do livro e controles
// ============================================

document.addEventListener("DOMContentLoaded", function () {
  const CHAVE_PREFS = "acervo_prefs_leitura";

  const params = new URLSearchParams(window.location.search);
  const idLivro = params.get("livro");
  const livro = CATALOGO_LIVROS.find(function (l) { return l.id === idLivro; });

  const elTituloBarra = document.getElementById("tituloBarraLeitor");
  const elCategoriaFrontis = document.getElementById("categoriaFrontis");
  const elTituloFrontis = document.getElementById("tituloFrontis");
  const elAutorFrontis = document.getElementById("autorFrontis");
  const elCorpoTexto = document.getElementById("corpoTextoLivro");
  const elPalco = document.getElementById("palcoLeitura");

  if (!livro) {
    elTituloBarra.textContent = "Livro não encontrado";
    elTituloFrontis.textContent = "Não encontramos esse livro";
    elAutorFrontis.textContent = "";
    elCorpoTexto.innerHTML = "<p>O título solicitado não está disponível no acervo. Volte ao catálogo para escolher outra obra.</p>";
    document.title = "Livro não encontrado — Acervo";
    return;
  }

  // Preenche cabeçalho e frontispício
  document.title = livro.titulo + " — " + livro.autor + " — Acervo";
  elTituloBarra.textContent = livro.titulo;
  elCategoriaFrontis.textContent = livro.categoriaLabel + " · " + livro.ano;
  elTituloFrontis.textContent = livro.titulo;
  elAutorFrontis.textContent = livro.autor;

  // Carrega o texto do livro
  fetch(livro.arquivo)
    .then(function (resp) {
      if (!resp.ok) throw new Error("Arquivo não encontrado");
      return resp.text();
    })
    .then(function (texto) {
      renderizarTexto(texto);
    })
    .catch(function () {
      elCorpoTexto.innerHTML = "<p>Não foi possível carregar o texto deste livro agora. Tente novamente em instantes.</p>";
    });

  function renderizarTexto(texto) {
    const blocos = texto.split(/\n\s*\n/).filter(function (b) { return b.trim().length > 0; });
    let html = "";

    blocos.forEach(function (bloco) {
      const linha = bloco.trim();
      // Detecta marcadores de capítulo (linhas curtas em maiúsculas, sem pontuação final)
      const pareceCapitulo = linha.length < 80 && linha === linha.toUpperCase() && !/[.,;]$/.test(linha);

      if (pareceCapitulo) {
        html += '<p class="marca-capitulo">' + escapeHtml(linha) + "</p>";
      } else {
        html += "<p>" + escapeHtml(linha).replace(/\n/g, "<br>") + "</p>";
      }
    });

    elCorpoTexto.innerHTML = html || "<p>Este livro ainda não tem texto disponível.</p>";
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  // ============================================
  // Preferências de leitura (persistidas)
  // ============================================
  function obterPrefs() {
    try {
      const salvas = JSON.parse(localStorage.getItem(CHAVE_PREFS) || "{}");
      return Object.assign({
        tamanhoFonte: 18,
        fonteFamilia: "serifada",
        espacamento: 1.8,
        temaLeitura: "dia",
        largura: "media"
      }, salvas);
    } catch (e) {
      return { tamanhoFonte: 18, fonteFamilia: "serifada", espacamento: 1.8, temaLeitura: "dia", largura: "media" };
    }
  }

  function salvarPrefs(prefs) {
    try {
      localStorage.setItem(CHAVE_PREFS, JSON.stringify(prefs));
    } catch (e) { /* segue sem persistir */ }
  }

  let prefs = obterPrefs();

  const mapaFontes = {
    "serifada": "'Lora', 'Iowan Old Style', serif",
    "sem-serifa": "-apple-system, 'Segoe UI', sans-serif",
    "legivel": "'Atkinson Hyperlegible', sans-serif"
  };

  const mapaLarguras = { "estreita": "560px", "media": "720px", "larga": "880px" };

  function aplicarPrefs() {
    document.documentElement.style.setProperty("--tamanho-fonte-leitura", prefs.tamanhoFonte + "px");
    document.documentElement.style.setProperty("--fonte-corpo-leitura", mapaFontes[prefs.fonteFamilia]);
    document.documentElement.style.setProperty("--altura-linha-leitura", prefs.espacamento);
    elPalco.style.maxWidth = mapaLarguras[prefs.largura];
    elPalco.setAttribute("data-tema-leitura", prefs.temaLeitura);
    document.getElementById("valorFonte").textContent = prefs.tamanhoFonte + "px";

    document.querySelectorAll(".opcao-pill[data-fonte]").forEach(function (b) {
      b.classList.toggle("ativo", b.getAttribute("data-fonte") === prefs.fonteFamilia);
    });
    document.querySelectorAll(".opcao-pill[data-largura]").forEach(function (b) {
      b.classList.toggle("ativo", b.getAttribute("data-largura") === prefs.largura);
    });
    document.querySelectorAll(".opcao-tema-amostra").forEach(function (b) {
      b.classList.toggle("ativo", b.getAttribute("data-temaleitura") === prefs.temaLeitura);
    });
    document.getElementById("sliderEspacamento").value = prefs.espacamento;
  }

  aplicarPrefs();

  document.getElementById("fonteMenor").addEventListener("click", function () {
    prefs.tamanhoFonte = Math.max(14, prefs.tamanhoFonte - 1);
    salvarPrefs(prefs); aplicarPrefs();
  });
  document.getElementById("fonteMaior").addEventListener("click", function () {
    prefs.tamanhoFonte = Math.min(28, prefs.tamanhoFonte + 1);
    salvarPrefs(prefs); aplicarPrefs();
  });

  document.querySelectorAll(".opcao-pill[data-fonte]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      prefs.fonteFamilia = btn.getAttribute("data-fonte");
      salvarPrefs(prefs); aplicarPrefs();
    });
  });

  document.querySelectorAll(".opcao-pill[data-largura]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      prefs.largura = btn.getAttribute("data-largura");
      salvarPrefs(prefs); aplicarPrefs();
    });
  });

  document.querySelectorAll(".opcao-tema-amostra").forEach(function (btn) {
    btn.addEventListener("click", function () {
      prefs.temaLeitura = btn.getAttribute("data-temaleitura");
      salvarPrefs(prefs); aplicarPrefs();
    });
  });

  document.getElementById("sliderEspacamento").addEventListener("input", function (e) {
    prefs.espacamento = parseFloat(e.target.value);
    salvarPrefs(prefs); aplicarPrefs();
  });

  // ============================================
  // Painel de configurações — abrir/fechar
  // ============================================
  const painelConfig = document.getElementById("painelConfig");
  const botaoConfig = document.getElementById("botaoConfig");
  const overlay = document.getElementById("overlayLeitor");

  function abrirPainel() {
    painelConfig.classList.add("aberto");
    overlay.classList.add("visivel");
    botaoConfig.setAttribute("aria-expanded", "true");
  }
  function fecharPainel() {
    painelConfig.classList.remove("aberto");
    overlay.classList.remove("visivel");
    botaoConfig.setAttribute("aria-expanded", "false");
  }

  botaoConfig.addEventListener("click", function () {
    painelConfig.classList.contains("aberto") ? fecharPainel() : abrirPainel();
  });
  overlay.addEventListener("click", fecharPainel);
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") fecharPainel();
  });

  // ============================================
  // Tema geral (dia/noite) do site dentro do leitor
  // ============================================
  const botaoTemaLeitor = document.getElementById("botaoTemaLeitor");
  function atualizarIconeTema() {
    const ehNoite = document.documentElement.getAttribute("data-tema") === "noite";
    botaoTemaLeitor.querySelector(".icone-sol").style.display = ehNoite ? "none" : "block";
    botaoTemaLeitor.querySelector(".icone-lua").style.display = ehNoite ? "block" : "none";
  }
  atualizarIconeTema();
  botaoTemaLeitor.addEventListener("click", function () {
    window.AcervoTema.alternarTema();
    atualizarIconeTema();
  });

  // ============================================
  // Barra de progresso de leitura
  // ============================================
  const trilhaProgresso = document.getElementById("trilhaProgresso");
  function atualizarProgresso() {
    const alturaTotal = document.documentElement.scrollHeight - window.innerHeight;
    const percentual = alturaTotal > 0 ? (window.scrollY / alturaTotal) * 100 : 0;
    trilhaProgresso.style.width = Math.min(100, Math.max(0, percentual)) + "%";
  }
  window.addEventListener("scroll", atualizarProgresso, { passive: true });
  atualizarProgresso();
});
