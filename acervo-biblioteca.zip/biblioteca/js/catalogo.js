// Catálogo de livros — domínio público
// Cada livro referencia um arquivo de texto em /books/

const CATALOGO_LIVROS = [
  {
    id: "dom-casmurro",
    titulo: "Dom Casmurro",
    autor: "Machado de Assis",
    ano: "1899",
    categoria: "romance",
    categoriaLabel: "Romance",
    paginas: 256,
    corCapa: "linear-gradient(155deg, #8C2F26, #5E1F18)",
    sinopse: "A narrativa de Bentinho, tomado pela dúvida sobre a fidelidade de Capitu, em um dos romances mais estudados da literatura brasileira.",
    arquivo: "books/dom-casmurro.txt"
  },
  {
    id: "memorias-postumas",
    titulo: "Memórias Póstumas de Brás Cubas",
    autor: "Machado de Assis",
    ano: "1881",
    categoria: "romance",
    categoriaLabel: "Romance",
    paginas: 208,
    corCapa: "linear-gradient(155deg, #3D4A3D, #28332A)",
    sinopse: "Um defunto autor narra sua própria vida com ironia e melancolia, inaugurando o realismo no Brasil.",
    arquivo: "books/memorias-postumas.txt"
  },
  {
    id: "o-cortico",
    titulo: "O Cortiço",
    autor: "Aluísio Azevedo",
    ano: "1890",
    categoria: "romance",
    categoriaLabel: "Romance",
    paginas: 224,
    corCapa: "linear-gradient(155deg, #A87C3F, #7A5A2C)",
    sinopse: "O retrato cru da vida em um cortiço carioca, onde o coletivo se torna o verdadeiro protagonista.",
    arquivo: "books/o-cortico.txt"
  },
  {
    id: "a-cidade-as-serras",
    titulo: "A Cidade e as Serras",
    autor: "Eça de Queirós",
    ano: "1901",
    categoria: "romance",
    categoriaLabel: "Romance",
    paginas: 240,
    corCapa: "linear-gradient(155deg, #5C5347, #3A332A)",
    sinopse: "Jacinto, farto do excesso da vida parisiense, busca o sentido simples da existência no interior de Portugal.",
    arquivo: "books/a-cidade-e-as-serras.txt"
  },
  {
    id: "iracema",
    titulo: "Iracema",
    autor: "José de Alencar",
    ano: "1865",
    categoria: "romance",
    categoriaLabel: "Romance Indianista",
    paginas: 128,
    corCapa: "linear-gradient(155deg, #6B7A4A, #4A5532)",
    sinopse: "A lenda poética do amor entre a índia Iracema e o português Martim, narrada em prosa lírica.",
    arquivo: "books/iracema.txt"
  },
  {
    id: "poesias-castro-alves",
    titulo: "Espumas Flutuantes",
    autor: "Castro Alves",
    ano: "1870",
    categoria: "poesia",
    categoriaLabel: "Poesia",
    paginas: 96,
    corCapa: "linear-gradient(155deg, #8C2F26, #A8493D)",
    sinopse: "Coletânea lírica do poeta dos escravos, voz mais ardente do romantismo brasileiro.",
    arquivo: "books/espumas-flutuantes.txt"
  },
  {
    id: "sonetos-camoes",
    titulo: "Sonetos",
    autor: "Luís de Camões",
    ano: "1595",
    categoria: "poesia",
    categoriaLabel: "Poesia Clássica",
    paginas: 80,
    corCapa: "linear-gradient(155deg, #A87C3F, #C9A05C)",
    sinopse: "Os sonetos que consolidaram Camões como o maior poeta da língua portuguesa.",
    arquivo: "books/sonetos-camoes.txt"
  },
  {
    id: "o-alienista",
    titulo: "O Alienista",
    autor: "Machado de Assis",
    ano: "1882",
    categoria: "conto",
    categoriaLabel: "Conto",
    paginas: 64,
    corCapa: "linear-gradient(155deg, #3D4A3D, #5A6B57)",
    sinopse: "Simão Bacamarte e sua obsessão científica pela loucura, numa sátira atemporal sobre o poder.",
    arquivo: "books/o-alienista.txt"
  },
  {
    id: "contos-clarice",
    titulo: "Antologia de Contos Clássicos",
    autor: "Vários Autores",
    ano: "1900",
    categoria: "conto",
    categoriaLabel: "Conto",
    paginas: 144,
    corCapa: "linear-gradient(155deg, #5C5347, #8C7F66)",
    sinopse: "Uma seleção de contos curtos de autores de língua portuguesa em domínio público.",
    arquivo: "books/antologia-contos.txt"
  },
  {
    id: "republica-platao",
    titulo: "A República",
    autor: "Platão",
    ano: "-380",
    categoria: "filosofia",
    categoriaLabel: "Filosofia",
    paginas: 320,
    corCapa: "linear-gradient(155deg, #2B2420, #4A4034)",
    sinopse: "O diálogo fundamental sobre justiça, governo ideal e a alegoria da caverna.",
    arquivo: "books/republica.txt"
  },
  {
    id: "arte-da-guerra",
    titulo: "A Arte da Guerra",
    autor: "Sun Tzu",
    ano: "-500",
    categoria: "filosofia",
    categoriaLabel: "Filosofia / Estratégia",
    paginas: 88,
    corCapa: "linear-gradient(155deg, #8C2F26, #4A1B16)",
    sinopse: "O tratado militar mais influente da história, sobre estratégia, liderança e tomada de decisão.",
    arquivo: "books/arte-da-guerra.txt"
  },
  {
    id: "principe-machiavel",
    titulo: "O Príncipe",
    autor: "Nicolau Maquiavel",
    ano: "1532",
    categoria: "filosofia",
    categoriaLabel: "Filosofia Política",
    paginas: 160,
    corCapa: "linear-gradient(155deg, #A87C3F, #5E461F);",
    sinopse: "O manual clássico sobre o exercício do poder, que deu origem ao termo 'maquiavélico'.",
    arquivo: "books/o-principe.txt"
  }
];

// Categorias disponíveis para filtro
const CATEGORIAS = [
  { id: "todos", label: "Todos" },
  { id: "romance", label: "Romance" },
  { id: "poesia", label: "Poesia" },
  { id: "conto", label: "Conto" },
  { id: "filosofia", label: "Filosofia" }
];
