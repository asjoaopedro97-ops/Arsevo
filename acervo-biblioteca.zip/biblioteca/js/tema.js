// ============================================
// Gerenciamento de tema (claro/noite) — global
// ============================================

(function () {
  const CHAVE_TEMA = "acervo_tema";

  function obterTemaSalvo() {
    try {
      return localStorage.getItem(CHAVE_TEMA);
    } catch (e) {
      return null;
    }
  }

  function salvarTema(tema) {
    try {
      localStorage.setItem(CHAVE_TEMA, tema);
    } catch (e) {
      /* localStorage indisponível — segue sem persistir */
    }
  }

  function aplicarTema(tema) {
    document.documentElement.setAttribute("data-tema", tema);
    document.body.setAttribute("data-tema", tema);
  }

  // Define tema inicial: salvo > preferência do sistema > dia
  const temaSalvo = obterTemaSalvo();
  const prefereSistemaEscuro = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
  const temaInicial = temaSalvo || (prefereSistemaEscuro ? "noite" : "dia");
  aplicarTema(temaInicial);

  function alternarTema() {
    const atual = document.documentElement.getAttribute("data-tema") === "noite" ? "noite" : "dia";
    const novo = atual === "noite" ? "dia" : "noite";
    aplicarTema(novo);
    salvarTema(novo);
    return novo;
  }

  document.addEventListener("DOMContentLoaded", function () {
    const botao = document.getElementById("botaoTema");
    if (botao) {
      botao.addEventListener("click", alternarTema);
    }
  });

  // Expor globalmente para outras páginas (ex: leitor)
  window.AcervoTema = { aplicarTema, alternarTema, obterTemaSalvo, salvarTema };
})();
