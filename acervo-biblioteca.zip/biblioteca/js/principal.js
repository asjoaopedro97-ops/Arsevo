// ============================================
// Página inicial — catálogo, filtros e busca
// ============================================

document.addEventListener("DOMContentLoaded", function () {
  const grade = document.getElementById("grade-livros");
  const filtrosContainer = document.getElementById("filtrosCategoria");
  let categoriaAtiva = "todos";

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function renderizarFiltros() {
    filtrosContainer.innerHTML = CATEGORIAS.map(function (cat) {
      const ativo = cat.id === categoriaAtiva ? "ativo" : "";
      return '<button class="chip-categoria ' + ativo + '" data-categoria="' + cat.id + '">' + escapeHtml(cat.label) + "</button>";
    }).join("");

    filtrosContainer.querySelectorAll(".chip-categoria").forEach(function (btn) {
      btn.addEventListener("click", function () {
        categoriaAtiva = btn.getAttribute("data-categoria");
        renderizarFiltros();
        renderizarGrade();
      });
    });
  }

  function criarCartaoLivro(livro) {
    const cartao = document.createElement("a");
    cartao.href = "leitor.html?livro=" + encodeURIComponent(livro.id);
    cartao.className = "cartao-livro";
    cartao.setAttribute("aria-label", "Ler " + livro.titulo + ", de " + livro.autor);

    cartao.innerHTML =
      '<div class="capa-livro" style="background:' + livro.corCapa + ';">' +
        '<span class="capa-categoria-tag">' + escapeHtml(livro.categoriaLabel) + "</span>" +
        '<div class="capa-titulo-grupo">' +
          "<h3>" + escapeHtml(livro.titulo) + "</h3>" +
          '<span class="autor-capa">' + escapeHtml(livro.autor) + "</span>" +
        "</div>" +
      "</div>" +
      '<div class="info-cartao">' +
        '<p class="titulo-info">' + escapeHtml(livro.titulo) + "</p>" +
        '<p class="autor-info">' + escapeHtml(livro.autor) + "</p>" +
        '<div class="meta-cartao">' +
          "<span>" + escapeHtml(livro.ano) + "</span>" +
          '<span class="ponto"></span>' +
          "<span>" + livro.paginas + " pág.</span>" +
        "</div>" +
      "</div>";

    return cartao;
  }

  function renderizarGrade() {
    const livrosFiltrados = categoriaAtiva === "todos"
      ? CATALOGO_LIVROS
      : CATALOGO_LIVROS.filter(function (l) { return l.categoria === categoriaAtiva; });

    grade.innerHTML = "";

    if (livrosFiltrados.length === 0) {
      grade.innerHTML = '<p style="color:var(--fg-suave);grid-column:1/-1;">Nenhum livro encontrado nesta categoria ainda.</p>';
      return;
    }

    livrosFiltrados.forEach(function (livro) {
      grade.appendChild(criarCartaoLivro(livro));
    });
  }

  renderizarFiltros();
  renderizarGrade();

  // Suporte a hash de categoria na URL (ex: index.html#romance)
  const hash = window.location.hash.replace("#", "");
  if (hash && CATEGORIAS.some(function (c) { return c.id === hash; })) {
    categoriaAtiva = hash;
    renderizarFiltros();
    renderizarGrade();
  }

  // ============================================
  // Busca
  // ============================================
  const botaoBusca = document.getElementById("botaoBusca");
  const painelBusca = document.getElementById("painelBusca");
  const campoBusca = document.getElementById("campoBusca");
  const resultadosBusca = document.getElementById("resultadosBusca");

  function abrirBusca() {
    painelBusca.classList.add("aberto");
    botaoBusca.setAttribute("aria-expanded", "true");
    setTimeout(function () { campoBusca.focus(); }, 100);
  }

  function fecharBusca() {
    painelBusca.classList.remove("aberto");
    botaoBusca.setAttribute("aria-expanded", "false");
  }

  if (botaoBusca) {
    botaoBusca.addEventListener("click", function () {
      const estaAberto = painelBusca.classList.contains("aberto");
      estaAberto ? fecharBusca() : abrirBusca();
    });
  }

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") fecharBusca();
  });

  if (campoBusca) {
    campoBusca.addEventListener("input", function () {
      const termo = campoBusca.value.trim().toLowerCase();
      if (!termo) {
        resultadosBusca.innerHTML = "";
        return;
      }
      const encontrados = CATALOGO_LIVROS.filter(function (l) {
        return l.titulo.toLowerCase().indexOf(termo) !== -1 || l.autor.toLowerCase().indexOf(termo) !== -1;
      });

      resultadosBusca.innerHTML = encontrados.length
        ? encontrados.map(function (l) {
            return '<a class="resultado-busca-item" href="leitor.html?livro=' + encodeURIComponent(l.id) + '">' +
              "<span>" + escapeHtml(l.titulo) + "</span>" +
              '<span class="autor-r">' + escapeHtml(l.autor) + "</span>" +
            "</a>";
          }).join("")
        : '<p style="color:var(--fg-suave);padding:10px 4px;">Nenhum resultado encontrado.</p>';
    });
  }

  // Menu mobile simples — alterna nav principal
  const menuMobile = document.getElementById("menuMobile");
  const navPrincipal = document.querySelector(".nav-principal");
  if (menuMobile && navPrincipal) {
    menuMobile.addEventListener("click", function () {
      const visivel = navPrincipal.style.display === "flex";
      navPrincipal.style.display = visivel ? "none" : "flex";
      navPrincipal.style.position = "absolute";
      navPrincipal.style.top = "76px";
      navPrincipal.style.left = "0";
      navPrincipal.style.right = "0";
      navPrincipal.style.background = "var(--bg)";
      navPrincipal.style.flexDirection = "column";
      navPrincipal.style.padding = "20px 32px";
      navPrincipal.style.borderBottom = "1px solid var(--borda)";
      navPrincipal.style.gap = "18px";
    });
  }
});
